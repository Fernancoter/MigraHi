# WebPanel: EtiquetadoOperadorWW

- **Module:** DB
- **Description:**  Etiquetado Operador
- **GAM Object:** No

## Data Dictionary / Parameters

| Name | Element Type | Data Type | Accessor | Description |
|---|---|---|---|---|
| IsAuthorized | Variable | Boolean |  | Is Authorized |
| WWPContext | Variable | GX_SDT |  | WWPContext |
| SecurityFunctionalityKeys | Variable | VARCHAR |  | Security Functionality Keys |
| HTTPRequest | Variable | GX_USRDEFTYP |  | HTTPRequest |
| TrnContext | Variable | GX_SDT |  | Trn Context |
| TrnContextAtt | Variable | GX_SDT |  | Trn Context Att |
| GridState | Variable | GX_SDT |  | Grid State |
| GridStateFilterValue | Variable | GX_SDT |  | Grid State Filter Value |
| OrderedBy | Variable | NUMERIC |  | Ordered By |
| OrderedDsc | Variable | Boolean |  | Ordered Dsc |
| OrderedByAux | Variable | NUMERIC |  | Ordered By Aux |
| FilterFullText | Variable | VARCHAR |  | Filter Full Text |
| ExcelFilename | Variable | VARCHAR |  | Excel Filename |
| ErrorMessage | Variable | VARCHAR |  | Error Message |
| ColumnsSelectorXML | Variable | LONGVARCHAR |  | Columns Selector XML |
| UserCustomValue | Variable | LONGVARCHAR |  | User Custom Value |
| ColumnsSelector | Variable | GX_SDT |  | Columns Selector |
| ColumnsSelectorAux | Variable | GX_SDT |  | Columns Selector Aux |
| Session | Variable | GX_USRDEFTYP |  | Session |
| ManageFiltersData | Variable | GX_SDT |  | Manage Filters Data |
| ManageFiltersXml | Variable | LONGVARCHAR |  | Manage Filters Xml |
| ManageFiltersExecutionStep | Variable | NUMERIC |  | Manage Filters Execution Step |
| TFEtiquetadoOperadorId | Variable | NUMERIC |  | TFEtiquetado Operador Id |
| TFEtiquetadoOperadorId_To | Variable | NUMERIC |  | TFEtiquetado Operador Id_To |
| TFEtiquetadoOperadorFechaHora | Variable | DATETIME |  | TFEtiquetado Operador Fecha Hora |
| TFEtiquetadoOperadorFechaHora_To | Variable | DATETIME |  | TFEtiquetado Operador Fecha Hora_To |
| DDO_EtiquetadoOperadorFechaHoraAuxDate | Variable | DATE |  | DDO_Etiquetado Operador Fecha Hora Aux Date |
| DDO_EtiquetadoOperadorFechaHoraAuxDateTo | Variable | DATE |  | DDO_Etiquetado Operador Fecha Hora Aux Date To |
| DDO_EtiquetadoOperadorFechaHoraAuxDateText | Variable | VARCHAR |  | DDO_Etiquetado Operador Fecha Hora Aux Date Text |
| TFEtiquetadoOperadorVoBoCarrete_Sel | Variable | NUMERIC |  | TFEtiquetado Operador Vo Bo Carrete_Sel |
| TFEtiquetadoOperadorLineaEtiquetadora_SelsJson | Variable | LONGVARCHAR |  | TFEtiquetado Operador Linea Etiquetadora_Sels Json |
| TFEtiquetadoOperadorLineaEtiquetadora_Sels | Variable | VARCHAR |  | TFEtiquetado Operador Linea Etiquetadora_Sels |
| TFEtiquetadoOperadorObservacionCarrete | Variable | VARCHAR |  | TFEtiquetado Operador Observacion Carrete |
| TFEtiquetadoOperadorObservacionCarrete_Sel | Variable | VARCHAR |  | TFEtiquetado Operador Observacion Carrete_Sel |
| TFOrdenEtiquetadoId | Variable | NUMERIC |  | TFOrden Etiquetado Id |
| TFOrdenEtiquetadoId_To | Variable | NUMERIC |  | TFOrden Etiquetado Id_To |
| TFPalletEtiquetadoId | Variable | NUMERIC |  | TFPallet Etiquetado Id |
| TFPalletEtiquetadoId_To | Variable | NUMERIC |  | TFPallet Etiquetado Id_To |
| TFCarreteEtiquetadoId | Variable | NUMERIC |  | TFCarrete Etiquetado Id |
| TFCarreteEtiquetadoId_To | Variable | NUMERIC |  | TFCarrete Etiquetado Id_To |
| TFCarreteEtiquetadoSerie | Variable | VARCHAR |  | TFCarrete Etiquetado Serie |
| TFCarreteEtiquetadoSerie_Sel | Variable | VARCHAR |  | TFCarrete Etiquetado Serie_Sel |
| DDO_TitleSettingsIcons | Variable | GX_SDT |  | DDO_Title Settings Icons |
| GAMSession | Variable | GX_EXTERNAL_OBJECT |  | GAMSession |
| GAMErrors | Variable | GX_EXTERNAL_OBJECT |  | GAMErrors |
| PageToGo | Variable | NUMERIC |  | Page To Go |
| GridCurrentPage | Variable | NUMERIC |  | Grid Current Page |
| GridPageCount | Variable | NUMERIC |  | Grid Page Count |
| GridAppliedFilters | Variable | VARCHAR |  | Grid Applied Filters |
| Update | Variable | CHARACTER |  | Update |
| IsAuthorized_Update | Variable | Boolean |  | Is Authorized_Update |
| Delete | Variable | CHARACTER |  | Delete |
| IsAuthorized_Delete | Variable | Boolean |  | Is Authorized_Delete |
| AGExportData | Variable | GX_SDT |  | AGExport Data |
| AGExportDataItem | Variable | GX_SDT |  | AGExport Data Item |
| IsAuthorized_Insert | Variable | Boolean |  | Is Authorized_Insert |
| IsAuthorized_EtiquetadoOperadorFechaHora | Variable | Boolean |  | Is Authorized_Etiquetado Operador Fecha Hora |
| TFEtiquetadoOperadorMotivoMolino_SelsJson | Variable | LONGVARCHAR |  | TFEtiquetado Operador Motivo Molino_Sels Json |
| TFEtiquetadoOperadorMotivoMolino_Sels | Variable | VARCHAR |  | TFEtiquetado Operador Motivo Molino_Sels |
| Today | Variable | DATE |  | Today |
| Time | Variable | CHARACTER |  | Time |
| Pgmname | Variable | CHARACTER |  | Pgmname |
| Pgmdesc | Variable | CHARACTER |  | Pgmdesc |

## Business Logic

### Start (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	TFEtiquetadoOperadorFechaHora_RangePicker.Attach(&DDO_EtiquetadoOperadorFechaHoraAuxDateText.InternalName)
	
	Grid.Rows = Page.Rows
	Grid_Empowerer.GridInternalName = Grid.InternalName
	DDO_GridColumnsSelector.GridInternalName = Grid.InternalName
	If &HTTPRequest.Method = HttpMethod.Get
		Do 'LoadSavedFilters'
	EndIf
	ddo_AGExport.TitleControlIdToReplace = BtnAGExport.InternalName
	&AGExportData = new()
	
	&AGExportDataItem = new()
	&AGExportDataItem.Title = ''
	&AGExportDataItem.Icon = ActionExport.Link()
	&AGExportDataItem.EventKey = !'Export'
	&AGExportDataItem.IsDivider = False
	&AGExportData.Add(&AGExportDataItem)
	
	&AGExportDataItem = new()
	&AGExportDataItem.Title = ''
	&AGExportDataItem.Icon = ActionExportReport.Link()
	&AGExportDataItem.EventKey = !'ExportReport'
	&AGExportDataItem.IsDivider = False
	&AGExportData.Add(&AGExportDataItem)
	
	DDC_Subscriptions.TitleControlIdToReplace = BtnSubscriptions.InternalName
	
	&IsAuthorized_EtiquetadoOperadorFechaHora = SecGAMIsAuthByFunctionalityKey.Udp(!'etiquetadooperadorview_Execute')
	
	&GAMSession = GAMSession.Get(&GAMErrors)
	DDO_Grid.GridInternalName = Grid.InternalName
	DDO_Grid.GAMOAuthToken = &GAMSession.Token
	Form.Caption = ' Etiquetado Operador'
	Do 'PrepareTransaction'
	Do 'LoadGridState'
	If &OrderedBy < 1
		&OrderedBy = 1
		Do 'SetDDOSortedStatus'
	EndIf
	&DDO_TitleSettingsIcons = GetWWPTitleSettingsIcons()
	DDO_GridColumnsSelector.TitleControlIdToReplace = BtnEditColumns.InternalName
	GridPaginationBar.RowsPerPageSelectedValue = Grid.Rows
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### Refresh (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	LoadWWPContext.Call(&WWPContext)
	Do 'CheckSecurityForActions'
	Do Case
		Case &ManageFiltersExecutionStep = 1
			&ManageFiltersExecutionStep = 2
		Case &ManageFiltersExecutionStep = 2
			&ManageFiltersExecutionStep = 0
			Do 'LoadSavedFilters'
	EndCase
	Do 'SaveGridState'
	
	If &Session.Get(!'DB.EtiquetadoOperadorWWColumnsSelector') <> ''
		&ColumnsSelectorXML = &Session.Get(!'DB.EtiquetadoOperadorWWColumnsSelector')
		&ColumnsSelector.FromXml(&ColumnsSelectorXML)
	Else
		Do 'InitializeColumnsSelector'
	EndIf
	EtiquetadoOperadorId.Visible = &ColumnsSelector.Columns.Item(1).IsVisible
	EtiquetadoOperadorFechaHora.Visible = &ColumnsSelector.Columns.Item(2).IsVisible
	EtiquetadoOperadorVoBoCarrete.Visible = &ColumnsSelector.Columns.Item(3).IsVisible
	EtiquetadoOperadorLineaEtiquetadora.Visible = &ColumnsSelector.Columns.Item(4).IsVisible
	EtiquetadoOperadorObservacionCarrete.Visible = &ColumnsSelector.Columns.Item(5).IsVisible
	EtiquetadoOperadorMotivoMolino.Visible = &ColumnsSelector.Columns.Item(6).IsVisible
	OrdenEtiquetadoId.Visible = &ColumnsSelector.Columns.Item(7).IsVisible
	PalletEtiquetadoId.Visible = &ColumnsSelector.Columns.Item(8).IsVisible
	CarreteEtiquetadoId.Visible = &ColumnsSelector.Columns.Item(9).IsVisible
	CarreteEtiquetadoSerie.Visible = &ColumnsSelector.Columns.Item(10).IsVisible
	&GridCurrentPage = Grid.CurrentPage
	&GridPageCount = Grid.PageCount
	&GridAppliedFilters = WWP_GetAppliedFiltersDescription(&Pgmname)
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### GridPaginationBar.ChangePage (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	Do Case
		Case GridPaginationBar.SelectedPage = !'Previous'
			Grid.PreviousPage()
		Case GridPaginationBar.SelectedPage = !'Next'
			Grid.NextPage()
		Otherwise
			&PageToGo.FromString(GridPaginationBar.SelectedPage)
			Grid.GotoPage(&PageToGo)
	EndCase
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### GridPaginationBar.ChangeRowsPerPage (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	Grid.Rows = GridPaginationBar.RowsPerPageSelectedValue
	Grid.FirstPage()
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### DDO_Grid.OnOptionClicked (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	Do Case
		Case DDO_Grid.ActiveEventKey = !'<#OrderASC#>' OR DDO_Grid.ActiveEventKey = !'<#OrderDSC#>'
			&OrderedBy.FromString(DDO_Grid.SelectedValue_get)
			&OrderedDsc = iif(DDO_Grid.ActiveEventKey = !'<#OrderDSC#>', true, false)
			Do 'SetDDOSortedStatus'
			Grid.FirstPage()
		Case DDO_Grid.ActiveEventKey = !'<#Filter#>'
			Do Case
				Case DDO_Grid.SelectedColumn = !'EtiquetadoOperadorId'
					&TFEtiquetadoOperadorId.FromString(DDO_Grid.FilteredText_get)
					&TFEtiquetadoOperadorId_To.FromString(DDO_Grid.FilteredTextTo_get)
				Case DDO_Grid.SelectedColumn = !'EtiquetadoOperadorFechaHora'
					&TFEtiquetadoOperadorFechaHora.FromString(DDO_Grid.FilteredText_get)
					&TFEtiquetadoOperadorFechaHora_To.FromString(DDO_Grid.FilteredTextTo_get)
					If Not &TFEtiquetadoOperadorFechaHora_To.IsEmpty()
						&TFEtiquetadoOperadorFechaHora_To.Set(&TFEtiquetadoOperadorFechaHora_To.Year(), &TFEtiquetadoOperadorFechaHora_To.Month(), &TFEtiquetadoOperadorFechaHora_To.Day(), 23, 59, 59)
					EndIf
				Case DDO_Grid.SelectedColumn = !'EtiquetadoOperadorVoBoCarrete'
					&TFEtiquetadoOperadorVoBoCarrete_Sel.FromString(DDO_Grid.SelectedValue_get)
				Case DDO_Grid.SelectedColumn = !'EtiquetadoOperadorLineaEtiquetadora'
					&TFEtiquetadoOperadorLineaEtiquetadora_SelsJson = DDO_Grid.SelectedValue_get
					&TFEtiquetadoOperadorLineaEtiquetadora_Sels.FromJson(&TFEtiquetadoOperadorLineaEtiquetadora_SelsJson)
				Case DDO_Grid.SelectedColumn = !'EtiquetadoOperadorObservacionCarrete'
					&TFEtiquetadoOperadorObservacionCarrete = DDO_Grid.FilteredText_get
					&TFEtiquetadoOperadorObservacionCarrete_Sel = DDO_Grid.SelectedValue_get
				Case DDO_Grid.SelectedColumn = !'EtiquetadoOperadorMotivoMolino'
					&TFEtiquetadoOperadorMotivoMolino_SelsJson = DDO_Grid.SelectedValue_get
					&TFEtiquetadoOperadorMotivoMolino_Sels.FromJson(&TFEtiquetadoOperadorMotivoMolino_SelsJson)
				Case DDO_Grid.SelectedColumn = !'OrdenEtiquetadoId'
					&TFOrdenEtiquetadoId.FromString(DDO_Grid.FilteredText_get)
					&TFOrdenEtiquetadoId_To.FromString(DDO_Grid.FilteredTextTo_get)
				Case DDO_Grid.SelectedColumn = !'PalletEtiquetadoId'
					&TFPalletEtiquetadoId.FromString(DDO_Grid.FilteredText_get)
					&TFPalletEtiquetadoId_To.FromString(DDO_Grid.FilteredTextTo_get)
				Case DDO_Grid.SelectedColumn = !'CarreteEtiquetadoId'
					&TFCarreteEtiquetadoId.FromString(DDO_Grid.FilteredText_get)
					&TFCarreteEtiquetadoId_To.FromString(DDO_Grid.FilteredTextTo_get)
				Case DDO_Grid.SelectedColumn = !'CarreteEtiquetadoSerie'
					&TFCarreteEtiquetadoSerie = DDO_Grid.FilteredText_get
					&TFCarreteEtiquetadoSerie_Sel = DDO_Grid.SelectedValue_get
			EndCase
			Grid.FirstPage()
	EndCase
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### Grid.Load (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	&Update = !'<i class="fa fa-pen"></i>'
	If (&IsAuthorized_Update)
		&Update.Link = DB.EtiquetadoOperador.Link(TrnMode.Update, EtiquetadoOperadorId)
	Endif
	&Delete = !'<i class="fa fa-times"></i>'
	If (&IsAuthorized_Delete)
		&Delete.Link = DB.EtiquetadoOperador.Link(TrnMode.Delete, EtiquetadoOperadorId)
	Endif
	If (&IsAuthorized_EtiquetadoOperadorFechaHora)
		EtiquetadoOperadorFechaHora.Link = DB.EtiquetadoOperadorView.Link(EtiquetadoOperadorId, '')
	Endif
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### DDO_GridColumnsSelector.OnColumnsChanged (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	&ColumnsSelectorXML = DDO_GridColumnsSelector.ColumnsSelectorValues
	&ColumnsSelector.FromJson(&ColumnsSelectorXML)
	SaveColumnsSelectorState(!'DB.EtiquetadoOperadorWWColumnsSelector', iif(&ColumnsSelectorXML.IsEmpty(), '', &ColumnsSelector.ToXml()))
	Refresh
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### ddo_ManageFilters.OnOptionClicked (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	Do Case
		Case ddo_ManageFilters.ActiveEventKey = !'<#Clean#>'
			Do 'CleanFilters'
			Grid.FirstPage()
			Refresh
		Case ddo_ManageFilters.ActiveEventKey = !'<#Save#>'
			Do 'SaveGridState'
			SaveFilterAs.Popup(!'DB.EtiquetadoOperadorWWFilters', &PgmName + !"GridState")
			&ManageFiltersExecutionStep = 2
			Refresh
		Case ddo_ManageFilters.ActiveEventKey = !'<#Manage#>'
			ManageFilters.Popup(!'DB.EtiquetadoOperadorWWFilters')
			&ManageFiltersExecutionStep = 2
			Refresh
		Otherwise
			&ManageFiltersXml = GetFilterByName(!'DB.EtiquetadoOperadorWWFilters', ddo_ManageFilters.ActiveEventKey)
			If &ManageFiltersXml.IsEmpty()
				msg('WWP_FilterNotExist')
			Else
				Do 'CleanFilters'
				SaveGridState.Call(&PgmName + !"GridState",  &ManageFiltersXml)
				&GridState.FromXml(&ManageFiltersXml)
				&OrderedBy = &GridState.OrderedBy
				&OrderedDsc = &GridState.OrderedDsc
				Do 'SetDDOSortedStatus' 
				Do 'LoadRegFiltersState'
				Grid.FirstPage()
				Refresh
			EndIf
	EndCase
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### 'DoInsert' (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	If (&IsAuthorized_Insert)
		DB.EtiquetadoOperador.Call(TrnMode.Insert, nullvalue(EtiquetadoOperadorId))
	Else
		msg("WWP_ActionNoLongerAvailable")
		Refresh
	Endif
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### ddo_AGExport.OnOptionClicked (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	Do Case
		Case ddo_AGExport.ActiveEventKey = !'Export'
			Do 'DoExport'
		Case ddo_AGExport.ActiveEventKey = !'ExportReport'
			Do 'DoExportReport'
	EndCase
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### DDC_Subscriptions.OnLoadComponent (Event)

```genexus
/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */
	WWPAux_WC.Object = WWP_SubscriptionsPanel.Create(!'EtiquetadoOperador', WWPBaseObjects.Notifications.WWP_NotificationAppliesTo.AnyRecord, '', '')
	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

### Rules (Rules)

```genexus

	/* Generated by DVelop Work With Plus Pattern [Start] - Do not change */



	/* Generated by DVelop Work With Plus Pattern [End] - Do not change */
```

